package com.emeboy04.potionskill;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class SkillCommand implements CommandExecutor, TabCompleter {

    private final PotionSkillPlugin plugin;
    private final SkillManager manager;

    public SkillCommand(PotionSkillPlugin plugin, SkillManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    private void say(CommandSender to, String text) {
        to.sendMessage(PotionSkillPlugin.color(text));
    }

    private String bar(int value, int max) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < max; i++) {
            sb.append(i < value ? "&a■" : "&8□");
        }
        return sb.toString();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String sub = args.length == 0 ? "info" : args[0].toLowerCase(Locale.ROOT);

        switch (sub) {
            case "info" -> {
                if (!(sender instanceof Player p)) {
                    say(sender, "&cHanya untuk player.");
                    return true;
                }
                Skill s = manager.getPlayerSkill(p.getUniqueId());
                if (s == null) {
                    p.sendMessage(plugin.msg("no-skill"));
                    return true;
                }
                int energy = manager.getEnergy(p.getUniqueId());
                int max = manager.getMaxEnergy();

                say(p, "&8&m      &r &cSkill kamu (efek ke musuh) &8&m      ");
                say(p, "&7Nama: " + s.displayName());
                say(p, "&7Energi: " + bar(energy, max) + " &e" + energy + "/" + max);
                if (energy <= 0) {
                    say(p, "&cSkill HILANG. Bunuh player lain untuk mendapat energi.");
                }
                for (PotionEffect e : s.effects()) {
                    say(p, "&8- &f" + e.getType().getKey().getKey()
                            + " &7level &e" + (e.getAmplifier() + 1)
                            + " &7(" + (e.getDuration() / 20) + " detik)");
                }
                say(p, "&7Tekan &eShift + F &7untuk menyusahkan musuh sekitar.");
            }

            case "list" -> {
                say(sender, "&aDaftar skill:");
                manager.getSkills().values().forEach(s ->
                        say(sender, "&8- &f" + s.id() + " &7= " + s.displayName()));
            }

            case "set" -> {
                if (!admin(sender)) return true;
                if (args.length < 3) {
                    say(sender, "&cGunakan: /pskill set <player> <skill>");
                    return true;
                }
                Player target = Bukkit.getPlayer(args[1]);
                Skill skill = manager.getSkill(args[2]);
                if (target == null) {
                    say(sender, "&cPlayer tidak ditemukan / offline.");
                    return true;
                }
                if (skill == null) {
                    say(sender, "&cSkill tidak ada. Cek /pskill list");
                    return true;
                }
                manager.setSkill(target.getUniqueId(), skill);
                say(sender, "&a" + target.getName() + " sekarang punya skill " + skill.displayName());
                say(target, "&7Skill kamu diubah menjadi " + skill.displayName());
            }

            case "energy" -> {
                if (!admin(sender)) return true;
                if (args.length < 3) {
                    say(sender, "&cGunakan: /pskill energy <player> <jumlah>");
                    return true;
                }
                Player target = Bukkit.getPlayer(args[1]);
                if (target == null) {
                    say(sender, "&cPlayer tidak ditemukan / offline.");
                    return true;
                }
                int amount;
                try {
                    amount = Integer.parseInt(args[2]);
                } catch (NumberFormatException ex) {
                    say(sender, "&cJumlah harus angka.");
                    return true;
                }
                manager.setEnergy(target.getUniqueId(), amount);
                int now = manager.getEnergy(target.getUniqueId());
                say(sender, "&aEnergi " + target.getName() + " diset ke " + now + "/" + manager.getMaxEnergy());
                say(target, "&7Energi kamu diubah menjadi &e" + now + "/" + manager.getMaxEnergy());
            }

            case "reroll" -> {
                if (!admin(sender)) return true;
                Player target;
                if (args.length >= 2) {
                    target = Bukkit.getPlayer(args[1]);
                } else if (sender instanceof Player p) {
                    target = p;
                } else {
                    say(sender, "&cGunakan: /pskill reroll <player>");
                    return true;
                }
                if (target == null) {
                    say(sender, "&cPlayer tidak ditemukan / offline.");
                    return true;
                }
                Skill s = manager.assignRandom(target.getUniqueId());
                if (s == null) {
                    say(sender, "&cTidak ada skill di config.");
                    return true;
                }
                say(sender, "&a" + target.getName() + " mendapat skill " + s.displayName());
                say(target, "&7Skill baru kamu: " + s.displayName());
            }

            case "reload" -> {
                if (!admin(sender)) return true;
                manager.load();
                say(sender, "&aConfig dimuat ulang. " + manager.getSkills().size() + " skill.");
            }

            default -> say(sender, "&cGunakan: /pskill <info|list|set|energy|reroll|reload>");
        }
        return true;
    }

    private boolean admin(CommandSender sender) {
        if (sender.hasPermission("potionskill.admin")) return true;
        sender.sendMessage(plugin.msg("no-permission"));
        return false;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        boolean isAdmin = sender.hasPermission("potionskill.admin");

        if (args.length == 1) {
            out.addAll(List.of("info", "list"));
            if (isAdmin) out.addAll(List.of("set", "energy", "reroll", "reload"));
        } else if (args.length == 2 && isAdmin
                && (args[0].equalsIgnoreCase("set") || args[0].equalsIgnoreCase("reroll")
                || args[0].equalsIgnoreCase("energy"))) {
            Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
        } else if (args.length == 3 && isAdmin) {
            if (args[0].equalsIgnoreCase("set")) {
                out.addAll(manager.getSkills().keySet());
            } else if (args[0].equalsIgnoreCase("energy")) {
                for (int i = 0; i <= manager.getMaxEnergy(); i++) out.add(String.valueOf(i));
            }
        }
        String last = args[args.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(s -> !s.toLowerCase(Locale.ROOT).startsWith(last));
        return out;
    }
}
